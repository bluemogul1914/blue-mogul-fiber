// app/api/check-availability/route.js
// (or pages/api/check-availability.js if using Pages Router - see below)
//
// Receives the Check Availability form submission from fiber.bluemogul.biz
// and forwards it as an ASR Pre-Order to the Frontier plugin on UISP.

const PLUGIN_URL = 'https://uisp.bluemogul.us/crm/_plugins/frontier-asr/public.php';

export async function POST(request) {
  try {
    const body = await request.json();

    const { name, phone, email, address, plan } = body;

    // Parse address — fiber site sends as single string "123 Main St, Houston, TX 77001"
    // Try to split it out, fall back gracefully
    let address_line1 = address || '';
    let city = '';
    let state = 'TX';
    let zip = '';

    const addrMatch = address?.match(/^(.+),\s*([^,]+),\s*([A-Z]{2})\s*(\d{5})?/);
    if (addrMatch) {
      address_line1 = addrMatch[1].trim();
      city          = addrMatch[2].trim();
      state         = addrMatch[3].trim();
      zip           = addrMatch[4]?.trim() || '';
    }

    // Send Pre-Order to Frontier ASR plugin
    const pluginRes = await fetch(`${PLUGIN_URL}?action=send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type:           'PRE-ORDER',
        address_line1,
        city,
        state,
        zip,
        contact_name:   name  || 'Web Inquiry',
        contact_phone:  phone || '',
        contact_email:  email || '',
        notes:          plan  ? `Interested plan: ${plan}` : '',
        source:         'fiber.bluemogul.biz',
      }),
    });

    const result = await pluginRes.json();

    return Response.json({
      success: result.success,
      pon:     result.pon,
      message: result.success
        ? 'We received your request! A Blue Mogul rep will contact you within 1 business day.'
        : 'Unable to check availability right now. Please call (346) 309-5514.',
    });

  } catch (err) {
    console.error('[check-availability]', err);
    return Response.json({
      success: false,
      message: 'Something went wrong. Please call (346) 309-5514.',
    }, { status: 500 });
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   IF YOU ARE USING PAGES ROUTER (pages/api/check-availability.js) USE THIS:
   ─────────────────────────────────────────────────────────────────────────────

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { name, phone, email, address, plan } = req.body;

    let address_line1 = address || '';
    let city = '', state = 'TX', zip = '';

    const addrMatch = address?.match(/^(.+),\s*([^,]+),\s*([A-Z]{2})\s*(\d{5})?/);
    if (addrMatch) {
      address_line1 = addrMatch[1].trim();
      city          = addrMatch[2].trim();
      state         = addrMatch[3].trim();
      zip           = addrMatch[4]?.trim() || '';
    }

    const pluginRes = await fetch(
      'https://uisp.bluemogul.us/crm/_plugins/frontier-asr/public.php?action=send',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'PRE-ORDER', address_line1, city, state, zip,
          contact_name: name || 'Web Inquiry', contact_phone: phone || '',
          contact_email: email || '', source: 'fiber.bluemogul.biz',
          notes: plan ? `Interested plan: ${plan}` : '',
        }),
      }
    );

    const result = await pluginRes.json();
    res.json({
      success: result.success,
      pon: result.pon,
      message: result.success
        ? 'We received your request! A rep will contact you within 1 business day.'
        : 'Unable to check availability right now. Please call (346) 309-5514.',
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Something went wrong.' });
  }
}
*/
