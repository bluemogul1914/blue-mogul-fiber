// hooks/useCheckAvailability.js
// Drop-in hook for the existing Check Availability form on fiber.bluemogul.biz
// Handles submission, loading state, and result messaging.

import { useState } from 'react';

export function useCheckAvailability() {
  const [status, setStatus]   = useState('idle');   // idle | loading | success | error
  const [message, setMessage] = useState('');
  const [pon, setPon]         = useState('');

  async function checkAvailability(formData) {
    setStatus('loading');
    setMessage('');
    setPon('');

    try {
      const res = await fetch('/api/check-availability', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(formData),
      });

      const data = await res.json();

      if (data.success) {
        setStatus('success');
        setMessage(data.message || 'Request received! We\'ll be in touch within 1 business day.');
        setPon(data.pon || '');
      } else {
        setStatus('error');
        setMessage(data.message || 'Unable to check availability. Please call (346) 309-5514.');
      }
    } catch (err) {
      setStatus('error');
      setMessage('Connection error. Please call (346) 309-5514.');
    }
  }

  function reset() {
    setStatus('idle');
    setMessage('');
    setPon('');
  }

  return { status, message, pon, checkAvailability, reset };
}
