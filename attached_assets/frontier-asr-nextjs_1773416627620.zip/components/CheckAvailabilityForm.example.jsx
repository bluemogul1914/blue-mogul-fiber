// HOW TO WIRE INTO YOUR EXISTING CHECK AVAILABILITY FORM
// ─────────────────────────────────────────────────────────────────────────────
// Find your existing form component (likely something like HeroForm.jsx,
// AvailabilityForm.jsx, or CheckAvailabilityForm.jsx) and make these changes:
//
// BEFORE (your existing form probably looks like this):
// ─────────────────────────────────────────────────────────────────────────────
//
// const handleSubmit = async (e) => {
//   e.preventDefault();
//   // ... existing logic
// };
//
// ─────────────────────────────────────────────────────────────────────────────
// AFTER — add the hook and update handleSubmit:
// ─────────────────────────────────────────────────────────────────────────────

'use client'; // remove if using Pages Router

import { useState } from 'react';
import { useCheckAvailability } from '@/hooks/useCheckAvailability';

export default function CheckAvailabilityForm() {
  const [form, setForm] = useState({
    name:    '',
    phone:   '',
    email:   '',
    address: '',
    plan:    '',
  });

  const { status, message, pon, checkAvailability, reset } = useCheckAvailability();

  const handleChange = (e) => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    await checkAvailability(form);
  };

  // ── SUCCESS STATE ───────────────────────────────────────────────────────────
  if (status === 'success') {
    return (
      <div className="check-availability-result success">
        {/* Keep your existing success UI, or use this: */}
        <div style={{ textAlign: 'center', padding: '24px' }}>
          <div style={{ fontSize: '48px' }}>🎉</div>
          <h3 style={{ color: '#fff', fontSize: '22px', margin: '12px 0 8px' }}>
            Great News!
          </h3>
          <p style={{ color: 'rgba(255,255,255,.85)', fontSize: '15px', lineHeight: 1.6 }}>
            {message}
          </p>
          {pon && (
            <p style={{ color: 'rgba(255,255,255,.5)', fontSize: '12px', marginTop: '12px' }}>
              Reference #: {pon}
            </p>
          )}
          <button
            onClick={reset}
            style={{
              marginTop: '16px', padding: '10px 22px',
              background: '#f57c00', color: '#fff',
              border: 'none', borderRadius: '6px',
              cursor: 'pointer', fontWeight: 'bold'
            }}
          >
            Check Another Address
          </button>
        </div>
      </div>
    );
  }

  // ── FORM STATE ──────────────────────────────────────────────────────────────
  return (
    <form onSubmit={handleSubmit}>
      {/* ── Keep ALL your existing form fields exactly as they are ─────────── */}
      {/* Just make sure each input has name= and onChange=handleChange         */}

      <input
        type="text"
        name="name"
        placeholder="Full Name"
        value={form.name}
        onChange={handleChange}
        required
      />
      <input
        type="tel"
        name="phone"
        placeholder="(555) 123-4567"
        value={form.phone}
        onChange={handleChange}
      />
      <input
        type="email"
        name="email"
        placeholder="john@example.com"
        value={form.email}
        onChange={handleChange}
      />
      <input
        type="text"
        name="address"
        placeholder="123 Main St, Houston, TX 77001"
        value={form.address}
        onChange={handleChange}
        required
      />
      <select name="plan" value={form.plan} onChange={handleChange}>
        <option value="">Select a plan</option>
        <option value="2GIG_BASIC">2 Gig Internet Only — $299.99/mo</option>
        <option value="2GIG_COMPLETE">Complete Solution — $449.99/mo</option>
      </select>

      {/* Error message */}
      {status === 'error' && (
        <p style={{ color: '#ff6b6b', fontSize: '13px', margin: '8px 0' }}>
          {message}
        </p>
      )}

      {/* ── Keep your existing button, just add disabled state ─────────────── */}
      <button
        type="submit"
        disabled={status === 'loading'}
        style={{ opacity: status === 'loading' ? 0.7 : 1 }}
      >
        {status === 'loading' ? '⏳ Checking...' : 'Check Availability ➤'}
      </button>

      <p style={{ fontSize: '11px', color: 'rgba(255,255,255,.5)', marginTop: '8px' }}>
        By submitting this form, you agree to receive calls or texts from Blue Mogul Fiber.
      </p>
    </form>
  );
}
