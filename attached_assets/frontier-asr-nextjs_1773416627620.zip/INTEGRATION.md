# Frontier ASR Integration — fiber.bluemogul.biz (Next.js / Replit)

## What This Does
When a visitor submits the "Check Availability" form on fiber.bluemogul.biz,
it sends an ASR Pre-Order to Frontier via your UISP plugin. You'll see every
inquiry appear in your Frontier ASR dashboard at:
  https://uisp.bluemogul.us/crm/_plugins/frontier-asr/public.php

---

## Setup (3 steps)

### Step 1 — Copy files into your Replit project

Copy these two files into your project:

  app/api/check-availability/route.js   →  your Next.js project root
  hooks/useCheckAvailability.js         →  your Next.js project root

If you're using the Pages Router instead of App Router, use the
commented-out version at the bottom of route.js and put it at:
  pages/api/check-availability.js

---

### Step 2 — Find your existing form component

Look in your Replit project for a file like:
  - components/HeroForm.jsx
  - components/AvailabilityForm.jsx
  - components/CheckAvailability.jsx
  - Or search for: "Check Availability" or "checkAvailability"

---

### Step 3 — Add the hook to your form

At the top of your form component, add:

  import { useCheckAvailability } from '@/hooks/useCheckAvailability';

Inside your component:

  const { status, message, pon, checkAvailability, reset } = useCheckAvailability();

Update your handleSubmit:

  const handleSubmit = async (e) => {
    e.preventDefault();
    await checkAvailability({
      name:    formState.name,     // match your existing state fields
      phone:   formState.phone,
      email:   formState.email,
      address: formState.address,  // "123 Main St, Houston, TX 77001"
      plan:    formState.plan,
    });
  };

Show success/error:

  {status === 'success' && <p>{message} (Ref: {pon})</p>}
  {status === 'error'   && <p style={{color:'red'}}>{message}</p>}

Disable button while loading:

  <button disabled={status === 'loading'}>
    {status === 'loading' ? 'Checking...' : 'Check Availability ➤'}
  </button>

---

## Address Format
The fiber.bluemogul.biz form has a single "Service Address" field.
The API route automatically parses it:
  "123 Main St, Houston, TX 77001"
    → address_line1: "123 Main St"
    → city: "Houston"
    → state: "TX"
    → zip: "77001"

If your form has separate fields, pass them individually:
  await checkAvailability({ name, phone, email,
    address: `${street}, ${city}, ${state} ${zip}`, plan });

---

## Environment Variables (optional, recommended)
Add to your Replit Secrets:

  FRONTIER_PLUGIN_URL = https://uisp.bluemogul.us/crm/_plugins/frontier-asr/public.php

Then in route.js change:
  const PLUGIN_URL = process.env.FRONTIER_PLUGIN_URL;

---

## Result Dashboard
Every Check Availability submission from the website will appear at:
  https://uisp.bluemogul.us/crm/_plugins/frontier-asr/public.php?action=dashboard

Look for orders with source = "fiber.bluemogul.biz" and type = "PRE-ORDER"
